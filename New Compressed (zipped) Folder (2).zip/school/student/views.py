from django.shortcuts import render

from .forms import SForm
from .models import stud

# Create your views here.
def show(request):
    return render(request,"home.html")

def register(request):
    from student.forms import studForm,SForm
    title="Student Registration"
    form= studForm(request.POST or None)

    if form.is_valid():


        fName =form.cleaned_data['First_Name']
        lName =form.cleaned_data['Last_Name']
        course =form.cleaned_data['Course']
        DOB =form.cleaned_data['Date_of_birth']



        from .models import stud
        p = stud(First_Name=fName,Last_Name =lName,Course=course, Date_of_birth=DOB)
        p.save()
        return render(request,'ack.html',{"title":"Registered Successfully"})


    context={
    "title":title,
    "form": form
    }


    return render(request,'register.html',context)


def existing(request):
    title = "All Registered Students"
    queryset =stud.objects.all()

    context ={
        "title":title,
        "queryset":queryset,
    }
    return render(request,'existing.html',context)
def search(request):
    title="Search Student"
    form=SForm(request.POST or None)
    if form.is_valid():
        fName = form.cleaned_data['First_Name']
        queryset = stud.objects.filter(First_Name=fName)
        if len(queryset)==0:
            return render(request,'ack.html',{'title':'Student Detail Not Found... Please Enter Correct Name'})
        context={
            'title':title,
            'queryset':queryset,
        }
        return render(request,'existing.html',context)

    context={
        'title':title,
        'form':form,
    }
    return render(request,'search.html',context)


def dropout(request):
    title="Delete Student"
    form=SForm(request.POST or None)
    if form.is_valid():
        fName = form.cleaned_data['First_Name']

        queryset = stud.objects.filter(First_Name=fName)
        if len(queryset)==0:
            return render(request,'ack.html',{'title':'Student Detail Not Found... Please Enter Correct Name'})
        else:
            queryset =stud.objects.filter(First_Name=fName).delete()
            return render(request,'ack.html',{'title':"Student removed from your database"})

    context={
        'title':title,
        'form':form,
    }
    return render(request,'search.html',context)


