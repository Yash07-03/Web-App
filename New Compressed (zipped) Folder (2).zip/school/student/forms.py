from django import forms

class studForm(forms.Form):
    First_Name = forms.CharField(max_length=30,label="First Name")
    Last_Name = forms.CharField(max_length=30,label ="Last Name")
    Course = forms.CharField(max_length=30, label = "Course Enrolled")
    Date_of_birth =forms.DateField()


class SForm(forms.Form):
    First_Name =forms.CharField(max_length=30)